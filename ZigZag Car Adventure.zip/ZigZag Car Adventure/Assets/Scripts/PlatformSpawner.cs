using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformSpawner : MonoBehaviour
{
    public GameObject platform;
    public Transform lastplatform;
    Vector3 lastPos;
    Vector3 newpos;
    public bool stop;
    // Start is called before the first frame update
    void Start()
    {
        lastPos = lastplatform.position;
        StartCoroutine(SpawnPlatform());
        //Genratepos();
    }

    // Update is called once per frame
    //void Update()
    //{
        
    //} 0 2
    void Genratepos()
    {
        newpos = lastPos;
        int rand = Random.Range(0, 2);
        if (rand > 0)
        {
            newpos.x += 2f;
        }
        else
        {
            newpos.z += 2f;
        }
        
        Instantiate(platform,newpos,Quaternion.identity);
    }
    IEnumerator SpawnPlatform()
    {
        while (!stop)
        {
            Genratepos();
            //Instantiate(platform, newpos, Quaternion.identity);
            lastPos = newpos;
            yield return new WaitForSeconds(0.2f);
        }
    }
}

