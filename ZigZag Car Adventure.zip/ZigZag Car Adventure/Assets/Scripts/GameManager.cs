using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class GameManager : MonoBehaviour
{
    public static GameManager instance;
    public bool isGameStarted;
    public GameObject PlatformSpawner;
    [Header("GameOver")]
    public GameObject gameOverPanel;
    public GameObject NewHighScore;
    public Text lastscore;
    [Header("Score")]
    public Text scoreText;
    public Text bestText;
    public Text DiamondText;
    public Text StarText;
    int score = 0;
    int bestScore, totalDiamond, totalStar;
    bool countScore;

   

    // Start is called before the first frame update
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
    }
    void Start()
    {
        totalDiamond = PlayerPrefs.GetInt("totalDiamond");
        DiamondText.text = totalDiamond.ToString();
        totalStar = PlayerPrefs.GetInt("totalstar");
        StarText.text = totalStar.ToString();
        bestScore=PlayerPrefs.GetInt("bestScore");
        bestText.text = bestScore.ToString();
    }

    // Update is called once per frame
    void Update()
    {
        if (!isGameStarted)
        {
            if (Input.GetMouseButtonDown(0))
            {
                GameStarted();
               
            }
        }
    }
    public void GameStarted()
    {
        Debug.Log("shahzeb Start");
        isGameStarted = true;
        PlatformSpawner.SetActive(true);
        countScore = true;
        StartCoroutine(UpdateScore());
        
    }
    public void GameOver()
    {
        Debug.Log("ShahzebOver");
        
        PlatformSpawner.SetActive(false);
        lastscore.text = score.ToString();
        countScore = false;
        StartCoroutine(OverPanel());
        if (score > bestScore)
        {
            NewHighScore.SetActive(true);
            PlayerPrefs.SetInt("bestScore", score);
        }
    }
    IEnumerator OverPanel()
    {
        yield return new WaitForSeconds(1);
        gameOverPanel.SetActive(true);
    }
    IEnumerator UpdateScore()
    {
        while (countScore)
        {
            yield return new WaitForSeconds(1f);
            score++;
            
            if (score > bestScore)
            {
                scoreText.text = score.ToString();
                bestText.text = score.ToString();
                //bestScore.text = score.ToString();
            }
            else {
                scoreText.text = score.ToString();
            }
            
        }
        
    }
    public void ReplayGame()
    {
        SceneManager.LoadScene("shahzeb1");
    }
}
