using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarControler : MonoBehaviour
{

    public float moveSpeed;
    public bool faceLeft, firstTab;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (GameManager.instance.isGameStarted)
        {
            move();
            CheckInput();
        }
        if (transform.position.y < 0)
        {
            GameManager.instance.GameOver();
        }
        
    }
    void move()
    {
        transform.position += transform.forward * moveSpeed * Time.deltaTime;
    }
    void CheckInput()
    {
        if (Input.GetMouseButtonDown(0))
        {
            ChangeDir();
        }
    }
    void ChangeDir()
    {
        if(faceLeft)
        {
            faceLeft = false;
            transform.rotation = Quaternion.Euler(0, 90, 0);
        }
        else
        {
            faceLeft = true;
            transform.rotation = Quaternion.Euler(0, 0, 0);
        }
    }
    
}
